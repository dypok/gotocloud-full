"""Model definitions for GoToCloud backend."""
